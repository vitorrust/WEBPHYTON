class Cliente:
    def __init__(self, id, patrimonio, renda, profissao, objetivo):
        self.id = id
        self.patrimonio = patrimonio
        self.renda = renda
        self.profissao = profissao
        self.objetivo = objetivo